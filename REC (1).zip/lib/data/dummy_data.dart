import '../models/recipe.dart';

const DUMMY_RECIPES = const [
  Recipe(
    id: 'r1',
    title: 'Spaghetti with Tomato Sauce',
    imageUrl:
        'https://upload.wikimedia.org/wikipedia/commons/thumb/2/20/Spaghetti_Bolognese_mit_Parmesan_oder_Grana_Padano.jpg/800px-Spaghetti_Bolognese_mit_Parmesan_oder_Grana_Padano.jpg',
    ingredients: [
      '4 Tomatoes',
      '1 Tablespoon of Olive Oil',
      '1 Onion',
      '250g Spaghetti',
      'Spices',
      'Cheese (optional)'
    ],
    steps: [
      'Cut the tomatoes and the onion into small pieces.',
      'Boil some water - add salt to it once it boils.',
      'Put the spaghetti into the boiling water - they should be done in about 10 to 12 minutes.',
      'In the meantime, heaten up some olive oil and add the cut onion.',
      'After 2 minutes, add the tomato pieces, salt, pepper and your other spices.',
      'The sauce will be done once the spaghetti are.',
      'Feel free to add some cheese on top of the finished dish.'
    ],
    duration: 20,
    complexity: 'Simple',
    affordability: 'Affordable',
  ),
  Recipe(
    id: 'r2',
    title: 'Toast Hawaii',
    imageUrl:
        'https://upload.wikimedia.org/wikipedia/commons/thumb/e/ef/Toast_Hawaii_-_b.jpg/1024px-Toast_Hawaii_-_b.jpg',
    ingredients: [
      '1 Slice White Bread',
      '1 Slice Ham',
      '1 Slice Pineapple',
      '1-2 Slices of Cheese',
      'Butter'
    ],
    steps: [
      'Butter one side of the white bread',
      'Layer ham, the pineapple and cheese on the white bread',
      'Bake the toast for round about 10 minutes in the oven at 200°C'
    ],
    duration: 10,
    complexity: 'Simple',
    affordability: 'Affordable',
  ),
  Recipe(
    id: 'r3',
    title: 'Classic Hamburger',
    imageUrl:
        'https://upload.wikimedia.org/wikipedia/commons/thumb/4/47/Hamburger_%28black_bg%29.jpg/1280px-Hamburger_%28black_bg%29.jpg',
    ingredients: [
      '300g Cattle Hack',
      '1 Tomato',
      '1 Cucumber',
      '1 Onion',
      'Ketchup',
      '2 Burger Buns'
    ],
    steps: [
      'Form 2 patties',
      'Fry the patties for c. 4 minutes on each side',
      'Quickly fry the buns for c. 1 minute on each side',
      'Bruch buns with ketchup',
      'Serve burger with tomato, cucumber and onion'
    ],
    duration: 45,
    complexity: 'Simple',
    affordability: 'Pricey',
  ),
  Recipe(
    id: 'r4',
    title: 'Wiener Schnitzel',
    imageUrl:
        'https://upload.wikimedia.org/wikipedia/commons/thumb/7/72/Schnitzel.JPG/1024px-Schnitzel.JPG',
    ingredients: [
      '8 Veal Cutlets',
      '4 Eggs',
      '200g Bread Crumbs',
      '100g Flour',
      '300ml Butter',
      '100g Vegetable Oil',
      'Salt',
      'Lemon Slices'
    ],
    steps: [
      'Tenderize the veal to about 2–4mm, and salt on both sides.',
      'On a flat plate, stir the eggs briefly with a fork.',
      'Lightly coat the cutlets in flour then dip into the egg, and finally, coat in breadcrumbs.',
      'Heat the butter and oil in a large pan (allow the fat to get very hot) and fry the schnitzels until golden brown on both sides.',
      'Make sure to toss the pan regularly so that the schnitzels are surrounded by oil and the crumbing becomes ‘fluffy’.',
      'Remove, and drain on kitchen paper. Fry the parsley in the remaining oil and drain.',
      'Place the schnitzels on a warmed plate and serve garnished with parsley and lemon slices.'
    ],
    duration: 60,
    complexity: 'Challenging',
    affordability: 'Luxurious',
  ),
  Recipe(
    id: 'r5',
    title: 'Salad with Smoked Salmon',
    imageUrl:
        'https://upload.wikimedia.org/wikipedia/commons/thumb/6/6f/Smoked_salmon_salad.jpg/1280px-Smoked_salmon_salad.jpg',
    ingredients: [
      'Arugula',
      'Lamb\'s Lettuce',
      'Parsley',
      'Fennel',
      '200g Smoked Salmon',
      'Mustard',
      'Balsamic Vinegar',
      'Olive Oil',
      'Salt and Pepper'
    ],
    steps: [
      'Wash and cut salad and herbs',
      'Dice the salmon',
      'Process mustard, vinegar and olive oil into a dessing',
      'Prepare the salad',
      'Add salmon cubes and dressing'
    ],
    duration: 15,
    complexity: 'Simple',
    affordability: 'Luxurious',
  ),
  Recipe(
    id: 'r6',
    title: 'Delicious Orange Mousse',
    imageUrl:
        'https://upload.wikimedia.org/wikipedia/commons/thumb/4/43/Fabrique_du_chocolat_Mousse_au_chocolat_et_%C3%A0_l%27orange.jpg/1280px-Fabrique_du_chocolat_Mousse_au_chocolat_et_%C3%A0_l%27orange.jpg',
    ingredients: [
      '4 Sheets of Gelatine',
      '150ml Orange Juice',
      '80g Sugar',
      '300g Yoghurt',
      '200g Cream',
      'Orange Peel',
    ],
    steps: [
      'Dissolve gelatine in pot',
      'Add orange juice and sugar',
      'Take pot off the stove',
      'Add 2 tablespoons of yoghurt',
      'Stir gelatin into remaining yoghurt',
      'Cool everything down in the refrigerator',
      'Whip the cream and lift it under the die orange mass',
      'Cool down again for at least 4 hours',
      'Serve with orange peel',
    ],
    duration: 240,
    complexity: 'Hard',
    affordability: 'Affordable',
  ),
  Recipe(
    id: 'r7',
    title: 'Pancakes',
    imageUrl:
        'https://upload.wikimedia.org/wikipedia/commons/thumb/4/43/Blueberry_pancakes_2.jpg/1280px-Blueberry_pancakes_2.jpg',
    ingredients: [
      '1 1/2 Cups all-purpose Flour',
      '3 1/2 Teaspoons Baking Powder',
      '1 Teaspoon Salt',
      '1 Tablespoon White Sugar',
      '1 1/4 cups Milk',
      '1 Egg',
      '3 Tablespoons Butter, melted',
    ],
    steps: [
      'In a large bowl, sift together the flour, baking powder, salt and sugar.',
      'Make a well in the center and pour in the milk, egg and melted butter; mix until smooth.',
      'Heat a lightly oiled griddle or frying pan over medium high heat.',
      'Pour or scoop the batter onto the griddle, using approximately 1/4 cup for each pancake. Brown on both sides and serve hot.'
    ],
    duration: 20,
    complexity: 'Simple',
    affordability: 'Affordable',
  ),
  Recipe(
    id: 'r8',
    title: 'Creamy Indian Chicken Curry',
    imageUrl:
        'https://upload.wikimedia.org/wikipedia/commons/thumb/8/86/Chicken_Tikka_Masala_with_Rice.jpg/1280px-Chicken_Tikka_Masala_with_Rice.jpg',
    ingredients: [
      '4 Chicken Breasts',
      '1 Onion',
      '2 Cloves of Garlic',
      '1 Piece of Ginger',
      '4 Tablespoons Almonds',
      '1 Teaspoon Cayenne Pepper',
      '500ml Coconut Milk',
    ],
    steps: [
      'Slice and fry the chicken breast',
      'Process onion, garlic and ginger into paste and sauté everything',
      'Add spices and stir fry',
      'Add chicken breast + 250ml of water and cook everything for 10 minutes',
      'Add coconut milk',
      'Serve with rice'
    ],
    duration: 35,
    complexity: 'Challenging',
    affordability: 'Pricey',
  ),
  Recipe(
    id: 'r9',
    title: 'Chocolate Souffle',
    imageUrl:
        'https://upload.wikimedia.org/wikipedia/commons/thumb/3/30/Chocolate_Souffle_2.jpg/1280px-Chocolate_Souffle_2.jpg',
    ingredients: [
      '1 Teaspoon melted Butter',
      '2 Tablespoons white Sugar',
      '2 Ounces 70% dark Chocolate, broken into pieces',
      '1 Tablespoon Butter',
      '1 Tablespoon all-purpose Flour',
      '4 1/3 tablespoons cold Milk',
      '1 Pinch Salt',
      '1 Pinch Cayenne Pepper',
      '1 Large Egg Yolk',
      '2 Large Egg Whites',
      '1 Pinch Cream of Tartar',
      '1 Tablespoon white Sugar',
    ],
    steps: [
      'Preheat oven to 190°C. Line a rimmed baking sheet with parchment paper.',
      'Brush bottom and sides of 2 ramekins lightly with 1 teaspoon melted butter; cover bottom and sides right up to the rim.',
      'Add 1 tablespoon white sugar to ramekins. Rotate ramekins until sugar coats all surfaces.',
      'Place chocolate pieces in a metal mixing bowl.',
      'Place bowl over a pan of about 3 cups hot water over low heat.',
      'Melt 1 tablespoon butter in a skillet over medium heat. Sprinkle in flour. Whisk until flour is incorporated into butter and mixture thickens.',
      'Whisk in cold milk until mixture becomes smooth and thickens. Transfer mixture to bowl with melted chocolate.',
      'Add salt and cayenne pepper. Mix together thoroughly. Add egg yolk and mix to combine.',
      'Leave bowl above the hot (not simmering) water to keep chocolate warm while you whip the egg whites.',
      'Place 2 egg whites in a mixing bowl; add cream of tartar. Whisk until mixture begins to thicken and a drizzle from the whisk stays on the surface about 1 second.',
      'Whisk in 1/3 of sugar. Whisk in another 1/3 of sugar. Whisk in remaining sugar. Whip until mixture is thick and glossy and resembles marshmallow creme: 2 to 3 minutes.',
      'Fold 1/2 of egg whites into chocolate mixture. Gently fold in remaining egg whites.',
      'Pour into prepared ramekins. Quantities are correct so fill the ramekins almost but not quite to the top.',
      'Place ramekins on prepared baking sheet. Bake in preheated oven until scuffles are puffed and have risen above the top of the rims, 12 to 15 minutes.',
    ],
    duration: 45,
    complexity: 'Hard',
    affordability: 'Affordable',
  ),
  Recipe(
    id: 'r10',
    title: 'Asparagus Salad with Cherry Tomatoes',
    imageUrl:
        'https://upload.wikimedia.org/wikipedia/commons/thumb/9/94/Salad_platter.jpg/1280px-Salad_platter.jpg',
    ingredients: [
      'White and Green Asparagus',
      '30g Pine Nuts',
      '300g Cherry Tomatoes',
      'Salad',
      'Salt, Pepper and Olive Oil'
    ],
    steps: [
      'Wash, peel and cut the asparagus',
      'Cook in salted water',
      'Salt and pepper the asparagus',
      'Roast the pine nuts',
      'Halve the tomatoes',
      'Mix with asparagus, salad and dressing',
      'Serve with Baguette'
    ],
    duration: 30,
    complexity: 'Simple',
    affordability: 'Luxurious',
  ),
];
