import 'package:flutter/material.dart';
import '../models/recipe.dart';
import '../data/dummy_data.dart';

class RecipeProvider with ChangeNotifier {
  final List<Recipe> _recipes = DUMMY_RECIPES;
  final List<String> _favoriteRecipeIds = [];

  List<Recipe> get recipes {
    return [..._recipes];
  }

  List<Recipe> get favoriteRecipes {
    return _recipes
        .where((recipe) => _favoriteRecipeIds.contains(recipe.id))
        .toList();
  }

  void toggleFavorite(String recipeId) {
    if (_favoriteRecipeIds.contains(recipeId)) {
      _favoriteRecipeIds.remove(recipeId);
    } else {
      _favoriteRecipeIds.add(recipeId);
    }
    notifyListeners();
  }

  bool isFavorite(String recipeId) {
    return _favoriteRecipeIds.contains(recipeId);
  }
}
