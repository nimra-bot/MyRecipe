import 'package:firebase_auth/firebase_auth.dart';

class ErrorHandler {
  static String getMessageFromErrorCode(String errorCode) {
    switch (errorCode) {
      case "email-already-in-use":
        return "This email is already registered.";
      case "weak-password":
        return "The password provided is too weak.";
      case "invalid-email":
        return "The email address is not valid.";
      case "user-not-found":
        return "No user found for that email.";
      case "wrong-password":
        return "Wrong password provided.";
      case "operation-not-allowed":
        return "This sensitive operation is not allowed.";
      case "user-disabled":
        return "This user has been disabled.";
      case "too-many-requests":
        return "Too many requests. Try again later.";
      case "network-request-failed":
        return "Network error. Check your connection.";
      case "credential-already-in-use":
         return "This credential is already associated with a different user account.";
      case "configuration-not-found":
        return "Firebase Auth not configured. Please enable Email/Password sign-in in Firebase Console.";
      default:
        return "An undefined error happened. (Code: $errorCode)";
    }
  }
}
