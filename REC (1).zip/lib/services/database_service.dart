import 'package:cloud_firestore/cloud_firestore.dart';
import '../models/recipe.dart';
import '../data/dummy_data.dart'; // Import dummy data


class DatabaseService {
  final FirebaseFirestore _db = FirebaseFirestore.instance;

  // Collection References
  CollectionReference get _recipesRef => _db.collection('recipes');
  CollectionReference get _usersRef => _db.collection('users');

  // Stream of all recipes
  Stream<List<Recipe>> get recipes {
    return _recipesRef.snapshots().map((snapshot) {
      return snapshot.docs.map((doc) {
        return Recipe.fromSnapshot(doc);
      }).toList();
    });
  }

  // Stream of user's saved recipe IDs
  Stream<List<String>> getUserSavedRecipeIds(String userId) {
    return _usersRef.doc(userId).snapshots().map((snapshot) {
      if (!snapshot.exists || snapshot.data() == null) {
        return [];
      }
      final data = snapshot.data() as Map<String, dynamic>;
      if (data.containsKey('savedRecipes')) {
        return List<String>.from(data['savedRecipes']);
      }
      return [];
    });
  }

  // Toggle Saved Recipe
  Future<void> toggleSavedRecipe(String userId, String recipeId, bool isSaved) async {
    if (isSaved) {
      // Remove
      await _usersRef.doc(userId).update({
        'savedRecipes': FieldValue.arrayRemove([recipeId])
      });
    } else {
      // Add
      await _usersRef.doc(userId).set({
        'savedRecipes': FieldValue.arrayUnion([recipeId])
      }, SetOptions(merge: true));
    }
  }

  // Seed Data
  Future<void> seedRecipes() async {
    final batch = _db.batch();
    for (var recipe in DUMMY_RECIPES) {
      final docRef = _recipesRef.doc(recipe.id); // Use existing IDs
      batch.set(docRef, {
        'title': recipe.title,
        'imageUrl': recipe.imageUrl,
        'ingredients': recipe.ingredients,
        'steps': recipe.steps,
        'duration': recipe.duration,
        'complexity': recipe.complexity,
        'affordability': recipe.affordability,
      });
    }
    await batch.commit();
  }
}
