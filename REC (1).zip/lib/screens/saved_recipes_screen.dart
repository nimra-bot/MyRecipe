import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../services/database_service.dart';
import '../services/auth_service.dart';
import '../models/recipe.dart';
import '../widgets/recipe_card.dart';

class SavedRecipesScreen extends StatelessWidget {
  const SavedRecipesScreen({super.key});

  @override
  Widget build(BuildContext context) {
    final user = Provider.of<AuthService>(context).currentUser;
    if (user == null) return const Scaffold(body: Center(child: Text("Please Login")));

    final db = Provider.of<DatabaseService>(context);

    return Scaffold(
      appBar: AppBar(title: const Text('My Favorites')),
      body: StreamBuilder<List<String>>(
        stream: db.getUserSavedRecipeIds(user.uid),
        builder: (context, savedSnapshot) {
          if (savedSnapshot.connectionState == ConnectionState.waiting) {
            return const Center(child: CircularProgressIndicator());
          }
           if (savedSnapshot.hasError) {
             return Center(child: Text('Error: ${savedSnapshot.error}'));
          }
          
          final savedIds = savedSnapshot.data ?? [];
          if (savedIds.isEmpty) {
             return const Center(child: Text('No favorites yet!'));
          }

          // Fetch actual recipe objects for these IDs
          // Note: In a real app with many items, you might want to query Firestore with 'whereIn'
          // or have the data available locally. Here, we'll listen to All Recipes and filter (OK for small datasets)
          // OR, ideally, fetch only what we need. For simplicity in this demo, accessing the all-recipes stream:
          return StreamBuilder<List<Recipe>>(
            stream: db.recipes,
            builder: (context, recipesSnapshot) {
               if (!recipesSnapshot.hasData) return const Center(child: CircularProgressIndicator());
               
               final allRecipes = recipesSnapshot.data!;
               final savedRecipes = allRecipes.where((r) => savedIds.contains(r.id)).toList();
               
                if (savedRecipes.isEmpty) {
                   // IDs exist but recipes might have been deleted?
                   return const Center(child: Text('No favorites found.'));
                }

               return GridView.builder(
                padding: const EdgeInsets.all(16),
                gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
                  crossAxisCount: 2,
                  childAspectRatio: 0.75, 
                  crossAxisSpacing: 16,
                  mainAxisSpacing: 16,
                ),
                itemCount: savedRecipes.length,
                itemBuilder: (context, index) {
                  return RecipeCard(
                    recipe: savedRecipes[index],
                    onTap: () {
                      Navigator.of(context).pushNamed(
                        '/recipe-detail',
                        arguments: savedRecipes[index],
                      );
                    },
                  );
                },
              );
            }
          );
        },
      ),
    );
  }
}
