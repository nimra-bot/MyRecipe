import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../services/database_service.dart';
import '../services/auth_service.dart';
import '../models/recipe.dart';
import '../widgets/recipe_card.dart';

class HomeScreen extends StatelessWidget {
  const HomeScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Discover Recipes'),
        actions: [
          IconButton(
            icon: const Icon(Icons.favorite_border),
            onPressed: () => Navigator.of(context).pushNamed('/saved-recipes'),
          ),
          IconButton(
            icon: const Icon(Icons.logout),
            onPressed: () {
              Provider.of<AuthService>(context, listen: false).signOut();
            },
          )
        ],
      ),
      body: StreamBuilder<List<Recipe>>(
        stream: Provider.of<DatabaseService>(context).recipes,
        builder: (context, snapshot) {
          if (snapshot.connectionState == ConnectionState.waiting) {
            return const Center(child: CircularProgressIndicator());
          }
          if (snapshot.hasError) {
            return Center(child: Text('Error: ${snapshot.error}'));
          }

          final recipes = snapshot.data ?? [];

          if (recipes.isEmpty) {
            return Center(
              child: Column(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  const Text('No recipes found in Firestore.'),
                  const SizedBox(height: 16),
                  ElevatedButton.icon(
                    onPressed: () async {
                       // Trigger seeding
                       try {
                         await Provider.of<DatabaseService>(context, listen: false).seedRecipes();
                         ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('Recipes Uploaded!')));
                       } catch (e) {
                         ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text('Error: $e')));
                       }
                    },
                    icon: const Icon(Icons.cloud_upload),
                    label: const Text('Upload Sample Data'),
                  )
                ],
              ),
            );
          }

          return GridView.builder(
            padding: const EdgeInsets.all(16),
            gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
              crossAxisCount: 2,
              childAspectRatio: 0.75, // Adjust for card height
              crossAxisSpacing: 16,
              mainAxisSpacing: 16,
            ),
            itemCount: recipes.length,
            itemBuilder: (context, index) {
              return RecipeCard(
                recipe: recipes[index],
                onTap: () {
                  Navigator.of(context).pushNamed(
                    '/recipe-detail',
                    arguments: recipes[index], // ID or object
                  );
                },
              );
            },
          );
        },
      ),
    );
  }
}
