import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:cached_network_image/cached_network_image.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import '../models/recipe.dart';
import '../services/database_service.dart';
import '../services/auth_service.dart';

class RecipeDetailScreen extends StatelessWidget {
  const RecipeDetailScreen({super.key});

  @override
  Widget build(BuildContext context) {
    // Expect Object? and cast, handling potential mismatch
    final args = ModalRoute.of(context)!.settings.arguments;
    Recipe? recipe;

    if (args is Recipe) {
      recipe = args;
    } else if (args is String) {
       // Ideally fetch by ID if passed string, but for now assuming object passed
       // You might want to implement a 'FutureBuilder' here if only ID is passed
       return const Scaffold(body: Center(child: Text("Loading..."))); 
    }

    if (recipe == null) {
      return const Scaffold(body: Center(child: Text("Error: No recipe data")));
    }
    
    final authService = Provider.of<AuthService>(context, listen: false);
    final user = authService.currentUser;

    return Scaffold(
      body: CustomScrollView(
        slivers: [
          SliverAppBar(
            expandedHeight: 300,
            pinned: true,
            flexibleSpace: FlexibleSpaceBar(
              title: Text(
                recipe.title,
                style: const TextStyle(
                  color: Colors.white, 
                  shadows: [Shadow(blurRadius: 4, color: Colors.black)],
                ),
              ),
              background: Hero(
                tag: recipe.id,
                child: CachedNetworkImage(
                  imageUrl: recipe.imageUrl,
                  fit: BoxFit.cover,
                  errorWidget: (context, url, error) => const Icon(Icons.error),
                ),
              ),
            ),
          ),
          SliverList(
            delegate: SliverChildListDelegate([
              const SizedBox(height: 10),
              _buildSectionTitle(context, 'Ingredients'),
              _buildIngredientsList(recipe.ingredients),
              const SizedBox(height: 10),
              _buildSectionTitle(context, 'Instructions'),
              _buildStepsList(recipe.steps),
              const SizedBox(height: 50),
            ]),
          ),
        ],
      ),
      floatingActionButton: StreamBuilder<List<String>>(
        stream: user != null 
          ? Provider.of<DatabaseService>(context).getUserSavedRecipeIds(user.uid)
          : const Stream.empty(),
        builder: (context, snapshot) {
          final savedIds = snapshot.data ?? [];
          final isSaved = savedIds.contains(recipe!.id);

          return FloatingActionButton(
            onPressed: () {
              if (user != null) {
                Provider.of<DatabaseService>(context, listen: false)
                    .toggleSavedRecipe(user.uid, recipe!.id, isSaved);
                
                ScaffoldMessenger.of(context).showSnackBar(
                  SnackBar(
                    content: Text(isSaved ? 'Removed from favorites' : 'Added to favorites'),
                    duration: const Duration(seconds: 1),
                  )
                );
              }
            },
            child: Icon(
              isSaved ? Icons.favorite : Icons.favorite_border,
              color: isSaved ? Colors.red : null,
            ),
          );
        },
      ),
    );
  }

  Widget _buildSectionTitle(BuildContext context, String title) {
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
      child: Text(
        title,
        style: Theme.of(context).textTheme.titleLarge,
      ),
    );
  }

  Widget _buildIngredientsList(List<String> ingredients) {
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 16),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: ingredients.map((ingredient) => 
          Card(
            margin: const EdgeInsets.symmetric(vertical: 4),
            child: Padding(
              padding: const EdgeInsets.all(12),
              child: Row(
                children: [
                   const Icon(Icons.check_circle_outline, size: 20, color: Colors.green),
                   const SizedBox(width: 10),
                   Expanded(child: Text(ingredient)),
                ],
              ),
            ),
          )
        ).toList(),
      ),
    );
  }

  Widget _buildStepsList(List<String> steps) {
      return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 16),
      child: Column(
        children: steps.asMap().entries.map((entry) {
          int idx = entry.key + 1;
          String step = entry.value;
          return Padding(
            padding: const EdgeInsets.only(bottom: 16),
            child: Row(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                CircleAvatar(
                  radius: 14,
                  child: Text('$idx', style: const TextStyle(fontSize: 12)),
                ),
                const SizedBox(width: 12),
                Expanded(child: Text(step, style: const TextStyle(fontSize: 16))),
              ],
            ),
          );
        }).toList(),
      ),
    );
  }
}
